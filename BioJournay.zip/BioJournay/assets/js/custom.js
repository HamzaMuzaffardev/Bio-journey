// Menu Link change Color
const navLinks = document.querySelectorAll('.nav-link-ul li a');

navLinks.forEach((e) => {
    e.addEventListener('click', () => {
        navLinks.forEach(link => link.classList.remove('active'));
        e.classList.add('active');
    });
});


// MenuBar Active
const MenuLines = document.querySelector('.menu-bar');
const MenuLineSpan = document.querySelectorAll('.menu-bar span');
const MenuBar = document.querySelector('#navbar');

MenuLines.addEventListener('click', ()=>{
    MenuBar.classList.toggle('active');
    MenuLineSpan.forEach(e =>{e.classList.toggle('active');})
    document.querySelector('html').classList.toggle('active');
})

// Scroll header
const header = document.querySelector("header");
let lastScrollPos = 0;

const hideHeader = function () {
  const isScrollBottom = lastScrollPos < window.scrollY;
  if (isScrollBottom) {
    header.classList.add("hide");
  } else {
    header.classList.remove("hide");
  }
  lastScrollPos = window.scrollY;
}

window.addEventListener("scroll", function () {
  if (window.scrollY >= 50) {
    hideHeader();
  }
});


// FAQS Accordions
$('.Accordion-head').click(function(e) {
    e.preventDefault();

    let $this = $(this);

    if ($this.next().hasClass('show')) {
        $this.next().removeClass('show').slideUp(250);

        $this.closest('.Accordion').removeClass('active');
        $this.removeClass('active');
        $this.find('h6').removeClass('active');
        $this.find('.Accordion-icon').removeClass('active');
        $this.find('.Accordion-icon-img').removeClass('active');
        $this.find('.Accordion-icon-img img').removeClass('active');
    } else {

        $this.closest('.Accordion').siblings().find('.Accordion-body').removeClass('show').slideUp(250);
        $this.closest('.Accordion').siblings().removeClass('active')
            .find('.Accordion-head').removeClass('active')
            .find('h6').removeClass('active')
            .siblings('.Accordion-icon').removeClass('active');

        $this.closest('.Accordion').siblings().find('.Accordion-icon-img').removeClass('active');
        $this.closest('.Accordion').siblings().find('.Accordion-icon-img img').removeClass('active');

        $this.next().toggleClass('show').slideToggle(250);
        $this.closest('.Accordion').addClass('active');
        $this.addClass('active');
        $this.find('h6').addClass('active');
        $this.find('.Accordion-icon').addClass('active');
        $this.find('.Accordion-icon-img').addClass('active');
        $this.find('.Accordion-icon-img img').addClass('active');
    }
});


// Feedback Slider
$(document).ready(function(){
    $('ul.feedback-body').slick({
        dots: true,
        infinite: true,
        slidesToShow: 1,
        adaptiveHeight: true
    });
});
$('.prev').click(function() {
    $('ul.feedback-body').slick('slickPrev');
});
$('.next').click(function() {
    $('ul.feedback-body').slick('slickNext');
});


// us js 
